export JAVA_PATH="java"
export CLASS_PATH="./lib/jstl-1.2.jar:./lib/mysql-connector-java-5.1.34.jar:fameplusWowzaUtility.jar:"
java -classpath $CLASS_PATH fameplus.wowza.main.Main